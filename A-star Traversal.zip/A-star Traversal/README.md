# Interactive mode
```
run python3 interactive.py
```

Keyboard shortcuts
| Key | Action         |
| --- | -------------  |
| q   | quit           |
| w   | move up        |
| s   | move down      |
| a   | move left      |
| d   | move right     |
| p   | peek unvisited |
| r   | reset          |
| n   | save map       |
| m   | load saved map |
| 1-9 | set map size   |
| 0   | map size 10    |