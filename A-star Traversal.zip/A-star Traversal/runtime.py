import time
from map import Map

MAP_SIZE = 101

def ns_to_ms(val):
  return val / 1000000

def avg_list_values(lst):
    return sum(lst) / len(lst)

def run(fn, name):
  i = 0
  times = []
  while i < 50:
    start = time.perf_counter_ns()
    fn()
    end = time.perf_counter_ns()

    # print(i)
    i += 1
    times.append(ns_to_ms(end - start))

  print(name, str(avg_list_values(times)))

map = Map(size=MAP_SIZE)
init = map.aStarForwardSearch()
while map == None or len(init) < 1200:
  map = Map(size=MAP_SIZE)
  init = map.aStarForwardSearch()

  
# map.print(peek=True)
print(init, len(init))

map.prefer_larger_g_value = True
run(lambda: map.aStarForwardSearch(), 'forward (manhattan - g value):')
map.prefer_larger_g_value = False
run(lambda: map.aStarForwardSearch(), 'forward (manhattan + g value):')
map.prefer_larger_g_value = True
run(lambda: map.aStarBackwardsSearch(), 'backward (manhattan - g value):')
map.prefer_larger_g_value = False
run(lambda: map.aStarBackwardsSearch(), 'backward (manhattan + g value):')
map.prefer_larger_g_value = True
run(lambda: map.adaptiveASearch(map.start), 'adaptive (manhattan - g value):')
map.prefer_larger_g_value = False
map.resetAdaptive()
run(lambda: map.adaptiveASearch(map.start), 'adaptive (manhattan + g value):')



# print()