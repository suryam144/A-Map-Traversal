import random
import os
import heapq

# Config constants
RESET_COLOR = "\033[0m"
PERCENT_CHANCE_IS_BLOCKED = 1/3
MAP_FOLDER_NAME='maps'
# End config constants

def colorize(str, color):
  color_code = ""

  if (color == "white_bg"):
    color_code = "\033[107m"
  elif (color == "cyan_bg"):
    color_code = "\033[46m"
  elif color == "red_bg":
    color_code = "\033[41m"
  elif color == "gray_bg":
    color_code = "\033[100m"
  elif color == "yellow_bg":
    color_code = "\033[103m"
  elif color == "red":
    color_code = "\033[31m"
  elif color == "green_bk":
    color_code = "\033[42m"

  return color_code + str + RESET_COLOR

class Node:
  is_blocked = False
  is_destination = False
  is_start = False
  is_visited = False
  manhattan_distance = 0
  a_value = None
  g_value = 0
  x = 0
  y = 0
  highlighted = False
  prefer_larger_g_value = False
  adaptive = False

  def __init__(self, is_blocked=False, is_destination = False, is_start = False, x=0, y=0):
    self.x = x
    self.y = y
    if is_start:
      self.is_start = True
    elif is_destination:
      self.is_destination = True
    else:
      self.is_blocked = is_blocked

  def get_value(self, force_adaptive=False):
    if (self.adaptive or force_adaptive) and self.a_value != None:
      return self.a_value
    elif self.prefer_larger_g_value:
      return self.manhattan_distance - self.g_value
    else:
      return self.manhattan_distance + self.g_value

  def __lt__(self, other):
    return self.get_value() < other.get_value()

  def __gt__(self, other):
    return self.get_value() > other.get_value()

  def to_string(self):
    if self.is_start:
      return "s"
    if self.is_destination:
      return "d"
    if self.is_blocked:
      return "b"
    return ""
  
  def get_id(self):
    return str(self.x) + "_" + str(self.y)

  def from_string(self, str):
    if str == "s":
      self.is_start = True
    elif str == "d":
      self.is_destination = True
    elif str == "b":
      self.is_blocked = True
    else:
      self.is_blocked = False
    return self

  def reset(self):
    self.is_visited = False
    self.highlighted = False
    self.g_value = 0
    self.adaptive = False

  def print(self, peek = False, highlight = False, is_current_location = False):
    output = str(self.get_value(force_adaptive=True)).rjust(3, ' ')
    # output = "   "
    if is_current_location:
      output = colorize("***", 'red')

    if self.is_start:
      output = colorize(output, 'yellow_bg')
    elif self.is_destination:
      output = colorize(output, 'cyan_bg')
    elif highlight and self.highlighted:
      output = colorize(output, 'green_bk')
    elif self.is_visited == False and peek == False:
      output = colorize(output, 'gray_bg')
    elif self.is_blocked is True:
      output = colorize(output, 'red_bg')
    else:
      output = colorize(output, 'white_bg')

    # Print cell
    print(output, end = '')
    # Print spacing between cols
    print('  ', end = '')

class Map:
  prefer_larger_g_value=True
  start=[]
  dest=[]
  current_location=[]

  def random_node(self, is_start, is_destination, x, y):
    if is_start:
      return Node(is_start=is_start, x=x, y=y)
    elif is_destination:
      return Node(is_destination=is_destination, x=x, y=y)
    else:
      is_blocked = random.random() <= PERCENT_CHANCE_IS_BLOCKED
      return Node(is_blocked = is_blocked, x=x, y=y)

  def __init__(self, size = 2):
    if size <= 1:
      print("minimum map size is 2")
      size = 2

    self.size = size
    start = [random.randint(0, size-1), random.randint(0, size-1)] 
    dest = start
    # update dest until it doesn't equal start
    while (dest == start):
      dest = [random.randint(0, size-1), random.randint(0, size-1)] 

    # set start as starting location
    self.current_location = start
    self.start = start
    self.dest = dest

    self.data = [
      [
        self.random_node(
          is_start=(start == [x, y]),
          is_destination=(dest == [x, y]),
          x = x,
          y = y
        ) 
        for x in range(0, size)
      ] 
      for y in range(0, size)
    ] 

  def manhattan_distance(self, start):
    startX = start[0]
    startY = start[1]
    return abs(startX - self.dest[0]) + abs(startY - self.dest[1])

  def calculate_all_manhattan_distances(self):
    for x in range(0, self.size):
      for y in range(0, self.size):
        if [x, y] != self.dest:
          self.data[y][x].manhattan_distance = self.manhattan_distance([x, y])

  def get_neighbors(self, x, y):
    neighbors = []
    if x > 0:
      # go left
      neighbors.append(self.data[y][x-1])
    if y > 0:
      # go up
      neighbors.append(self.data[y-1][x])
    if x < self.size - 1:
      # go right
      neighbors.append(self.data[y][x+1])
    if y < self.size - 1:
      # go down
      neighbors.append(self.data[y+1][x])
    return neighbors

  def search(self, startIndicies, destIndicies, adaptive = False):
    self.reset()
    H = []
    heapq.heapify(H)
    startX = startIndicies[0]
    startY = startIndicies[1]
    startNode = self.data[startY][startX]
    heapLength = 1
    heapq.heappush(H, startNode)

    prevNodes = {startNode.get_id(): None}
    gValues = {startNode.get_id(): 0}
    startNode.g_value = 0
    startNode.prefer_larger_g_value = self.prefer_larger_g_value
    startNode.adaptive = adaptive
    startNode.is_visited = True
    destNode = None

    # traverse neighbors until we destination
    # otherwise there is no path to destination
    while heapLength > 0:
      crnt = heapq.heappop(H)
      heapLength -= 1

      if crnt.x == destIndicies[0] and crnt.y == destIndicies[1]:
        destNode = crnt
        break

      for neighbor in self.get_neighbors(crnt.x, crnt.y):
        if neighbor.is_blocked == False and neighbor.is_visited == False:
          prevNodes[neighbor.get_id()] = crnt
          # calcualte g value
          neighbor.adaptive = adaptive
          neighbor.prefer_larger_g_value = self.prefer_larger_g_value
          neighbor_g_value = gValues[crnt.get_id()] + 1
          gValues[neighbor.get_id()] = neighbor_g_value
          neighbor.g_value = neighbor_g_value
          # add to heap
          heapq.heappush(H, neighbor)
          neighbor.is_visited = True
          heapLength += 1
        else:
          neighbor.is_visited = True

    path = []

    self.reset()

    if destNode == None:
      return 'unreachable'

    # calculate path by backtracking all
    # nodes that got us to destinationq
    crnt2 = destNode
    length = 0
    while crnt2 != None and crnt2.get_id() in prevNodes:
      crnt2.highlighted = True
      path.append(crnt2)
      if adaptive:
        crnt2.a_value = length
      length += 1
      crnt2 = prevNodes[crnt2.get_id()]

    path.reverse()
    return path

  def aStarForwardSearch(self):
    self.calculate_all_manhattan_distances()
    return self.search(self.start, self.dest, adaptive=False)

  def aStarBackwardsSearch(self):
    self.calculate_all_manhattan_distances()
    return self.search(self.dest, self.start, adaptive=False)

  def adaptiveASearch(self, start):
    self.calculate_all_manhattan_distances()
    return self.search(start, self.dest, adaptive=True)

  def pathToStrong(self, path):
    arr = []
    if isinstance(path, str) == False:
      for crnt in path:
        arr.append(crnt.get_id())
      return arr
    else:
      return path

  def move(self, direction):
    x = self.current_location[0]
    y = self.current_location[1]

    if direction == 'up':
      y = max(y-1, 0)
    elif direction == 'down':
      y = min(y+1, self.size-1)
    elif direction == 'left':
      x = max(x-1, 0)
    elif direction == 'right':
      x = min(x+1, self.size-1)

    new_location_node = self.data[y][x]
    new_location_node.is_visited = True
    if new_location_node.is_blocked != True:
      self.current_location = [x, y]

  def reset(self):
    for row in self.data:
      for node in row:
        node.reset()
    self.current_location = self.start

  def resetAdaptive(self):
    for row in self.data:
      for node in row:
        node.a_value = None

  def to_string(self):
    y = 0
    str_out = str(self.size)+'\n'
    for row in self.data:
      # start new line only if this
      # isn't the first row of the map
      if y > 0:
        str_out += '\n'
      # join string representation of nodes in row
      row_str = ",".join([node.to_string() for node in row])
      str_out += row_str
      y += 1
    return str_out

  def from_string(self, input_str):
    # first row denotes size of map
    y = -1
    for row in input_str.split('\n'):
      # get size of map
      if y == -1:
        self.size = int(row)
        self.data = [[0 for _ in range(0, self.size)] for _ in range(0, self.size)]
      # handle cols of map
      else:
        x = 0
        for node in [Node().from_string(node_str) for node_str in row.split(',')]:
          self.data[y][x] = node
          if node.is_start:
            self.start = [x, y]
          if node.is_destination:
            self.dest = [x, y]
          x += 1
      y += 1
    self.reset()

  def save(self, name):
    map_file_path = os.path.join(MAP_FOLDER_NAME, name+'.txt')
    text_file = open(map_file_path, "w")
    text_file.write(self.to_string())
    text_file.close()

  def load(self, name):
    map_file_path = os.path.join(MAP_FOLDER_NAME, name+'.txt')
    map_string = open(map_file_path, 'r').read()
    self.from_string(map_string)

  def print(self, peek = False, highlight = False):
    for y in range(len(self.data)):
      row = self.data[y]
      for x in range(len(row)):
        node = row[x]
        node.print(peek, highlight, is_current_location = self.current_location == [x, y])
      print('\n')
  
  def printColorKey(self):
    print(
      colorize(" ", 'yellow_bg') + " = start, " +
      colorize(" ", 'cyan_bg') + " = destination, " + 
      colorize("***", 'red') + " = location,\n" + 
      colorize(" ", 'gray_bg') + " = unvisited, " + 
      colorize(" ", 'red_bg') + " = blocked, " +
      colorize(" ", 'white_bg') + " = unblocked"
    )


map = Map(10)