from console.utils import wait_key
from map import Map
from os import system, name, wait

#create a function called clear(). You can name this anything you want.
def clear():
  if name == "nt":
    #if windows, linux
    system("cls")
  else:
    #mac, etc.
    system("clear")

map = Map()

peek = False
exit = False
error = False
highlight = False
saved = ""
path = ""

while exit != True:
  # clear()
  map.print(peek, highlight=True)
  map.printColorKey()
  print("Prefer larger g value: " + str(map.prefer_larger_g_value))
  print(path)
  # print("forward path", map.aStarForwardSearch())
  # print("backwards path", map.aStarBackwardsSearch())
  

  if error:
    print('"' + key + '" is not recognized')
    error = False

  key = wait_key().lower()

  if key == "q":
    exit = True
  elif key == "w":
    map.move("up")
  elif key == "s":
    map.move("down")
  elif key == "a":
    map.move("left")
  elif key == "d":
    map.move("right")
  elif key == "p":
    peek = not peek
  elif key == "h":
    highlight = not highlight
  elif key == "r":
    map.reset()
  elif key == "f":
    path = map.pathToStrong(map.aStarForwardSearch())
  elif key == "b":
    path = map.pathToStrong(map.aStarBackwardsSearch())
  elif key == "z":
    startX = int(input("start x: "))
    startY = int(input("start y: "))
    path = map.pathToStrong(map.adaptiveASearch([startX, startY]))
  elif key == "g":
    map.prefer_larger_g_value = not map.prefer_larger_g_value
  elif key == "n":
    file_name = input("filename to save map to: ")
    saved = map.save(file_name)
  elif key == "m":
    file_name = input("name of map file: ")
    map.load(file_name) 
  elif key == '0':
    map = Map(size=101) 
  elif key.isnumeric() and key != "1":
    map = Map(size=int(key) * 5)
  else:
    error = True